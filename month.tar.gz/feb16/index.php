<html><head><title>Space Wars 5959</title></head>

<body bgcolor="#FF8844">
<center><h2>Space Wars 5959</h2>
<table width="600" border="1" cellspacing="0" cellpadding="2"><tr><td>
<center><applet code="SpaceWars" archive="SpaceWars.jar" height="520" width="400"></applet></center><br><br>
Basic Rules:<br>
<ul><li>Press the left mouse button to shoot.  You can only fire once every quarter-second.  When you can shoot, you will see the yellow bullet at the top of your ship.</li>
<li>Press the right mouse button to toggle auto-fire.  If auto-fire is set, you will fire as soon as possible.</li>
<li>The goal of the game is to shoot as many of the enemies as you can, as fast as possible, without getting hit yourself.</li>
<li>You lose about 15% of your points each time you get hit.  You are charged 1 point for each shot fired, but get (3+2*level) points for shooting a ship, and a bonus for completing a level in under 80 seconds.</li>
<li>The orange, yellow, green, and purple ships will fire faster bullets than the basic red ships.  All of the ships will also fire more often as you increase in level.</li></ul>

</td></tr></table></center>
</body></html>
