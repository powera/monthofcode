<html><head><title>Mandelbrot Viewer</title></head>

<body bgcolor="#FF8844">
<center><h2>Mandelbrot Viewer</h2>
<table width="600" border="1" cellspacing="0" cellpadding="2"><tr><td>

<a href="interactive.php">Interactive Viewer</a><br><br>

<a href="mandelbrot.php?l=-2&t=1.5&s=3&p=300">PHP Mandelbrot</a> - ~25 seconds to do 100 iterations on 90000 pixels, Color<br><br>

<a href="/perl/feb07/mandelbrot.pl?l=-2&t=1.5&s=3&p=300">PERL Mandelbrot</a> - ~10 seconds to do 100 iterations on 90000 pixels, B&W<br><br>

<a href="/cgi-bin/feb07/mandelbrot.exe?l=-2&t=1.5&s=3&p=300&i=100">C Mandlebrot</a> - ~.4 seconds to do 100 iterations on 90000 pixels, Color

</td></tr></table></center>
</body></html>
