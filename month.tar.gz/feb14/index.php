<html><head><title>Java World</title></head>

<body bgcolor="#FF8844">
<center><h2>Java World</h2>
<table width="600" border="1" cellspacing="0" cellpadding="2"><tr><td>
<center><applet code="JavaWorld" archive="JavaWorld.jar" height="400" width="450"></applet></center><br>
An object consists of a shape (cube, pyramid, sphere, cylinder, cone), a size (very small, small, medium, large, very large), and a color (black, white, gray, red, orange, yellow, green, blue, purple).  Some alternate words are accepted.  If you do not specify a type, it will be assumed to be medium, red, or cube for object creation, and will serve as a wildcard for any other operation.  There are limits to which objects you can put other objects on.<br><br>
Supported Operations (everything is case-insensitive):
<ul><li>add (object1) - Adds an object1 on the ground
<li>add (object1) on (object2) - Adds an object1 on an existing object2
<li>how many (object1) - Determines how many objects there are of type object1
<li>how many (object1) on (object2) - Determines how many objects there are of type object1 on object2
<li>move (object1) to (object2) - Moves an object1 to an object2
<li>remove (object1) - Removes an object1 that does not have any other objects on it
<li>what supports (object1) - Determines what objects are supporting object1.
</ul>

</td></tr></table></center>
</body></html>
