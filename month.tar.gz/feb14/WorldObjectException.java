class WorldObjectException extends Exception {

  public WorldObjectException() {
  }
  public WorldObjectException(String msg) {
    super(msg);
  }
}