<html><head><title>Cryptogram Tools</title></head>

<body bgcolor="#FF8844">
<center><h2>Cryptogram Tools</h2>
<table width="600" border="1" cellspacing="0" cellpadding="2"><tr><td>
Substitution Cipher Tools:
<ul><li><a href="sub_encode.php">Encoder</a></li>
<li><a href="sub_decode.php">Decoding Tools</a></li></ul>
</td></tr></table></center>
</body></html>