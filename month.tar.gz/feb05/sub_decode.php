<html><head><title>Decoding Tools</title></head>

<body bgcolor="#FF8844">
<center><h2>Decoding Tools</h2>
<table width="600" border="1" cellspacing="0" cellpadding="2"><tr><td>
Enter the cryptogram text here:<br><br>
<form method="post" action="sub_decode_2.php">
<textarea name="crypt" rows=6 cols=60></textarea><br><br>
<input type="Submit" value="Submit"></form>
</td></tr></table></center>
</body></html>