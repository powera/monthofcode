<html><head><title>Numerical Evaluator</title></head>

<body bgcolor="#FF8844">
<center><h2>Numerical Evaluator</h2>
<table width="600" border="1" cellspacing="0" cellpadding="2"><tr><td>
Please enter an expression using numbers, +, -, *, /, and parentheses.  No implied multiplication.
<form method="post" action="/perl/feb13/eval.pl">
<input name="function">
<input type="submit" value="Evaluate">
</form>
</td></tr></table></center>
</body></html>
