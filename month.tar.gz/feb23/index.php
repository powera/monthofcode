<html><head><title>Vignere Encoder</title></head>

<body bgcolor="#FF8844">
</script>
<center><h2>Vignere Encoder</h2>
<table width="600" border="1" cellspacing="0" cellpadding="2"><tr><td>
All non-alphabetic characters in the text will be unchanged and skipped over by the algorithm.  Any non-alphanumeric characters in the code will be removed.  
<form method='post' action='/perl/feb23/vignere.pl'>
<table><tr><td align='right'>Text</td><td><textarea name="orig" rows="6" cols="40"></textarea></td></tr>
<tr><td>Code</td><td><input name="code"></td></tr></table>
<input type="submit" value="Submit">
</textarea>

</td></tr></table></center>
</body></html>
