<?php
$user="feb11";
$pass="password";

$db = mysql_connect(localhost, $user, $pass);
mysql_select_db("feb11",$db);

?>
