<? $user="feb18";
$pass="password";
$db=mysql_connect(localhost,$user,$pass);
mysql_select_db("feb18",$db); ?>