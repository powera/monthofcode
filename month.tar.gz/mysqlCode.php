<html><head><title>mySQL Code</title></head>

<body bgcolor="#FF8844">
<center><h2>mySQL Code</h2>
<table width="600" border="1" cellspacing="0" cellpadding="2"><tr><td>

<a href="index.php">Month of Code Home</a><br><br>

<a href="feb11/">February 11</a> - Flash Card - Uses PHP and mySQL - Select one of the three flash card sets.  A random entry is selected and one of the fields designated as "unique" for that set will display. (For example, for a math problem, the problem is unique but the answer is not.  For Chinese-English translation, both languages would be unique.). Clicking "View Solution" will display all the other information associated with the card.  You can also select the level for the problem you want.  New data sets or entries can be added relatively easily with only mySQL queries.  A tool to add words to the Chinese Vocabulary dataset is linked.<br><br>

<a href="feb17/">February 17</a> - Stock Price Tools - Uses PHP and mySQL - Displays a chart with the stock prices for any S&P 500 stock from Dec 23, 2005 to Feb 16, 2007.<br><br>

<a href="feb18/">February 18</a> - Web Board - Uses PHP/mySQL - You can enter your name, a comment title, and a comment.  Functions more like a guest book, as there is no capacity for threaded comments.  You can go back and forward to view 20 entries at a time, or link to a single entry.  Also includes an RSS feed of the information.<br><br>

</td></tr></table></center>
</body></html>
