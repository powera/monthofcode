<html><head><title>Java Code</title></head>

<body bgcolor="#FF8844">
<center><h2>Java Code</h2>
<table width="600" border="1" cellspacing="0" cellpadding="2"><tr><td>
<a href="index.php">Month of Code Home</a><br><br>

<a href="feb08/">February 8</a> - 3D Tic-Tac-Toe - Uses Java - Click on the square to play there.  Four in a row wins, in any direction.  There is a basic AI which will be tough for a beginner to beat.  When there is a winner, the completed squares will be highlighted.<br><br>

<a href="feb12/">February 12</a> - Word Find Generator - Uses Java - Creates a 16x16 wordfind using up to 25 words of 5 letters or greater.  Words are from a corpus of over 500 words.  To select a word, click on the first letter of the word, and drag to the last letter of the word.  Click "New Game" to generate a new board, or "Show Solution" to view the location of all the words.<br><br>

<a href="feb14/">February 14</a> - "Java World" - Uses Java - Block world simulator similar to the famous SHRDLU, but with more limited abilities.  You can add, move, and remove objects, as well as ask some basic questions about the state of the world.  Known Bug - Large objects are larger than very large objects. <br><br>

<a href="feb16/">February 16</a> - Space Wars 5959 - Uses Java - A Space Invaders-type game.  Shoot the ships without getting hit yourself.  Try to beat your previous high score.  Use left-mouse button to fire or right-mouse button to toggle auto-fire.<br><br>

<a href="feb21/">February 21</a> - "Java Town" - Uses Java - Applet of a car driving down a road in mock-3D.  The houses and cross street will randomly move each time the car reaches the end of the road, to demonstrate the use of perspective.  Unfortunately, I couldn't figure out anything for you to do in this one other than watch.<br><br>

<a href="feb24/">February 24</a> - Card Game - Uses Java - A random hand is dealt.  Click on the cards to select them for replacement, or deal a fresh hand from a new deck.<br><br>

<a href="feb28/">February 28</a> - Town Model - Uses Java - An arbitrary number of points (set to 3) move around the area.  The position they are attracted to is dependent on their location, and they move randomly towards that location.  Unfortunately, it is not particularly configurable.<br> 

</td></tr></table></center>
</body></html>
