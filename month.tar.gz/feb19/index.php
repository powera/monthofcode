<html><head>
<script language="javascript" src="metalwars.js">
<title>Metal Wars</title></head>
<body bgcolor="#FF8844">

<center><h2>Metal Wars</h2>
<table width="600" border="1" cellspacing="0" cellpadding="2"><tr><td>
<span id="mainBody">Welcome to Metal Wars!  The game where you start as a low-level investor in various metals, and attempt to become wealthy in just 30 days.  Please enter your name so we can get started!
<br><form name="form1" onSubmit="return false;"><input name="pName"> <input type="button" value="Start Playing" onClick="startGame();"></form></span>
</td></tr></table></center>
</body></html>
