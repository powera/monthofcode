<html><head>
<script language="javascript" src="wumble.js">
<title>Hunt the Wumble</title></head>
<body bgcolor="#FF8844">

<center><h2>Hunt the Wumble</h2>
<table width="600" border="1" cellspacing="0" cellpadding="2"><tr><td>
<span id="mainBody">Welcome to Hunt the Wumble!  Please enter your name so we can get started!
<br><form name="form1" onSubmit="return false;"><input name="pName"> <input type="button" value="Start Playing" onClick="startGame();"></form></span>
</td></tr></table></center>
</body></html>
