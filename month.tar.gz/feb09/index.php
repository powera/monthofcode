<html><head><title>Word Problem Generator</title>
<script language="javascript" src="wordprob.js"></script>
</head>

<body bgcolor="#FF8844" onLoad="getProblem();">
<center><h2>Word Problem Generator</h2>
<table width="600" border="1" cellspacing="0" cellpadding="2"><tr><td>
<span id="problemSpan">
</span>
<span id="solutionSpan">
</span>
<br><br>
<input type="button" value="Show Solution" onClick="showSolution();">
<input type="button" value="New Problem" onClick="getProblem();">
</td></tr></table></center>
</body></html>
