<html><head><title>JavaScript Code</title></head>

<body bgcolor="#FF8844">
<center><h2>JavaScript Code</h2>
<table width="600" border="1" cellspacing="0" cellpadding="2"><tr><td>

<a href="index.php">Month of Code Home</a><br><br>

<a href="feb03/">February 3</a> - Addition Applet - Uses only JavaScript - Enter a level.  It randomly generates an addition problem with numbers up to around the square root of the level (with scaling at lower levels).  When you get a problem right, your level goes up by the correct sum.  It tracks your current session's percentage.  If you refresh the page, your stats will be cleared, but it will auto-populate the level.<br><br>

<a href="feb04/">February 4</a> - Color Picker - Uses JavaScript to update the image, and PHP to generate the image with the desired colors - Enter a hex-color code for the background, text, and field.  A "Flag" designed in honor of the Super Bowl, with a football field, endposts, and the words "Colts" and "Bears" will be automatically updated with your color selections.<br><br>

<a href="feb10/">February 10</a> - Compound Interest Calculator - Uses only Javascript - Calculates amount based on principal, interest rate, and time period.<br><br>

<a href="feb22/">February 22</a> - Beat the Clock - Uses Javascript and PHP - Pick a board size, and hit start.  Click on the numbers in order starting with 1 as fast as you can.  Try to beat the goal times.<br><br>

<a href="feb25/">February 25</a> - Unit Converter - Uses JavaScript - Converts between various units of length, volume, and mass.<br><br>

<a href="feb27/">February 27</a> - John Conway's Game of Life - Uses JavaScript - Does the game of life simulation.  You can check or uncheck boxes manually.  On iteration, a new cell will be born if it is adjacent vertically, horizontally, or diagonally to exactly 3 cells, and an existing cell will survive if it is adjacent to 2 cells.<br><br>

</td></tr></table></center>
</body></html>
