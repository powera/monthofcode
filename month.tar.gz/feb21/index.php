<html><head><title>Java Town</title></head>

<body bgcolor="#FF8844">
<center><h2>Java Town</h2>
<table width="600" border="1" cellspacing="0" cellpadding="2"><tr><td>

<center><applet code="RacingGame" archive="RacingGame.jar" width="500" height="500"></applet></center>

</td></tr></table></center>
</body></html>
