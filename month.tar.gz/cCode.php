<html><head><title>C Code</title></head>

<body bgcolor="#FF8844">
<center><h2>C Code</h2>
<table width="600" border="1" cellspacing="0" cellpadding="2"><tr><td>
<a href="index.php">Month of Code Home</a><br><br>
<a href="feb07/">February 7</a> - Mandelbrot Viewer - Uses PHP, Perl, and C to create images (with GD), PHP for navigation pages - There are three separate pages which can create images of the Mandelbrot set.  As performance is an order of magnitude better using C, the zoomable version of the Mandelbrot set is written in C.  It loops colors after 48 iterations, and you can change the size of the image or increase the iteration count.  You can also click on the image to zoom in on that point.<br><br>

<a href="feb15/">February 15</a> - Neural Networker - Uses C - The C program can either construct a random neural network of arbitrary size or load one from a file, and conduct learning on that.  This is implemented with a web interface on the specific function (x*Input1+y*Input2+1)/(2+x+y), with X and Y user inputs.  The program will do up to 25000 training cycles with randomly generated inputs, with a "score" being displayed at different levels.

</td></tr></table></center>
</body></html>
