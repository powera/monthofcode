<html><head><title>3-D Tic Tac Toe</title></head>

<body bgcolor="#FF8844">
<center><h2>3-D Tic Tac Toe</h2>
<table width="600" border="1" cellspacing="0" cellpadding="2"><tr><td>
<applet code="TicTacToe" width="180" height="540"></applet></td>
<td><center><b>Rules of the Game</b></center>
<ol><li>Click on a square to play there.</li>
<li>Four in a row wins: horizontally, vertically, or diagonally.  76 different ways to win.</li>
<li>When you win, the squares used to make the tic-tac-toe will light up.</li>
<li>Click on "AI O" or "Human O" to toggle between Human and AI control of O.</li>
<li>The "score" is an indicator of who is winning.  Positive corresponds to X, negative corresponds to O.</li>
<li>Click reset to start a new game.</li>
</ol>

</td></tr></table></center>
</body></html>
