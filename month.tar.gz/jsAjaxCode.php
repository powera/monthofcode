<html><head><title>JS/AJAX Code</title></head>

<body bgcolor="#FF8844">
<center><h2>JS/AJAX Code</h2>
<table width="600" border="1" cellspacing="0" cellpadding="2"><tr><td>

<a href="index.php">Month of Code Home</a><br><br>

<a href="feb06/">February 6</a> - Hunt the Wumble - Uses PHP and AJAX - After entering your name, you are placed in the dungeon of the wumble, with two rounds of ammunition.  You must traverse the dungeon and attempt to shoot the mysterious wumble.  Don't walk into its lair or the wumble will flee the dungeon! (Do not confuse this with the similar Hunt the Wumpus game.)<br><br>

<a href="feb09/">February 9</a> - Word Problems - Uses AJAX and PHP back-end -  Automatically generates one of 6 different types of word problems.<br><br>

<a href="feb19/">February 19</a> - Metal Wars - Uses PHP and AJAX - Basically like Dope Wars, only with metals instead of drugs.  Try to beat $1000000 in just 30 days.<br><br>

</td></tr></table></center>
</body></html>
