<html><head><title>PERL Code</title></head>

<body bgcolor="#FF8844">
<center><h2>PERL Code</h2>
<table width="600" border="1" cellspacing="0" cellpadding="2"><tr><td>

<a href="index.php">Month of Code Home</a><br><br>

<a href="feb05/">February 5</a> - Cryptogram Tools - Uses PERL for the encryption, and PHP for the decryption tools.  Uses Javascript for some minor tools. - The "Encrypt" page takes as argument a plaintext and a 26-character cipher to user for the encryption.  This can be generated randomly by Javascript.  Pressing the "Encode" button will translate the text, retaining cases, and leaving any punctuation, numbers, etc. unchanged.  The "Decoding Tools" page takes a cryptogram as argument.  It will display a letter distribution for the page text, along with a list of one to four letter words in the text sample.  Some useful solving tips are included as well.<br><br>

<a href="feb07/">February 7</a> - Mandelbrot Viewer - Uses PHP, Perl, and C to create images (with GD), PHP for navigation pages - There are three separate pages which can create images of the Mandelbrot set.  As performance is an order of magnitude better using C, the zoomable version of the Mandelbrot set is written in C.  It loops colors after 48 iterations, and you can change the size of the image or increase the iteration count.  You can also click on the image to zoom in on that point.<br><br>

<a href="feb13/">February 13</a> - Numerical Evaluator - Uses PERL - Parses a mathematical expression containing numerical values, +-*/, and parentheses.  Displays the steps taken in order to evaluate the expression, and prints the result.  Known Bug - Subtraction processes the arguments in reverse order; i.e. a-b will return b-a. <br><br>

<a href="feb23/">February 23</a> - Vignere Cypher Generator - Uses PERL - Encrypts a text using a given cipher.<br><br>

</td></tr></table></center>
</body></html>
